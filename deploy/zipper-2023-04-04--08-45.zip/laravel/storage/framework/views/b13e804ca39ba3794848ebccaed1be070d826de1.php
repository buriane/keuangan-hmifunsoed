


<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800 text-center">Data Pembayaran Uang Kas</h1>

<div class="row">
    <div class="col-lg-6 col-sm-12">
        <div class="mb-3">
            <div class="d-inline">
                <button class="btn btn-dark btn-icon-split">
                    <a href="/kas/create" class="btn btn-dark btn-icon-split">
                        <span class="icon text-white-50">
                            <i class="fa fa-plus"></i>
                        </span>
                        <span class="text">Tambah</span>
                    </a>
                </button>
            </div>
        </div>
    </div>
</div>

<?php if(session()->has('sukses')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('sukses')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('peringatan')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session('peringatan')); ?>

    </div>
<?php endif; ?>

<div class="card shadow mb-5">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Menampilkan hasil untuk : </h6>
        <table>
            <tr>
                <td>Nama</td>
                <td>&nbsp;:&nbsp;</td>
                <td><?php echo e($identitas->nama); ?></td>
            </tr>
            <tr>
                <td>Divisi</td>
                <td>&nbsp;:&nbsp;</td>
                <td><?php echo e($identitas->divisi); ?></td>
            </tr>
        </table>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Bulan</th>
                        <th>Media</th>
                        <th>Nominal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th class="text-center" colspan="3">Total</th>
                        <th style="text-align:right ;"><script> document.write(rp(<?php echo e($history->sum('nominal')); ?>)) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($data->tanggal); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->bulan); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->dana->nama); ?></td>
                            <td style="text-align:right ;"><script> document.write(rp(<?php echo e($data->nominal); ?>)) </script></td>
                            <td>
                                <a href="/kas/<?php echo e($data->id); ?>/edit" class="btn btn-success btn-sm"><span><i class="fa fa-pencil"></i></span></a>
                                <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#hapus-<?php echo e($data->id); ?>"><span><i class="fa fa-trash"></i></span></a>
                            </td>
                        </tr>
                        <div class="modal fade" id="hapus-<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">Apakah anda yakin? Tekan tombol lanjutkan untuk menghapus data.</div>
                                    <div class="modal-footer">
                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                                        <form action="/kas/<?php echo e($data->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-primary">Lanjutkan</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/680/19367680/laravel/resources/views/kas/manage.blade.php ENDPATH**/ ?>