


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-3 text-gray-800 text-center">Tambah Data Pembayaran Uang Kas</h1>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow mb-5">
            <div class="card-body">
                <form method="post" action="/kas" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <label for="tanggal">Tanggal</label>
                            <input type="date" class="form-control form-control-user" id="tanggal" name="tanggal" required>
                        </div>
                        <div class="col-sm-6">
                            <label for="dana_id">Media</label>
                            <select class="form-control form-control-user" name="dana_id" id="dana_id" required>
                                <option value="" selected hidden>Pilih</option>
                                <?php $__currentLoopData = $dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <label for="dana_id">Nama Pengurus</label>
                            <select class="deposit_id form-control form-control-user" name="kas_id" id="kas_id" required>
                                <option value="" selected hidden>Pilih</option>
                                <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $d = $nama->where('divisi', $div->divisi) ?>
                                    <option value="" class="font-weight-bold" disabled><?php echo e($div->divisi); ?></option>
                                    <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-7 mb-3 mb-sm-0">
                            <label for="bulan">Bulan</label>
                            <select class="form-control form-control-user" name="bulan-1" id="bulan-1" required>
                                <option value="" selected hidden>Pilih</option>
                                <option value="April">April</option>
                                <option value="Mei">Mei</option>
                                <option value="Juni">Juni</option>
                                <option value="Juli">Juli</option>
                                <option value="Agustus">Agustus</option>
                                <option value="September">September</option>
                                <option value="Oktober">Oktober</option>
                                <option value="November">November</option>
                            </select>
                        </div>
                        <div class="col-sm-5">
                            <label for="nominal">Denda</label>
                            <select class="form-control form-control-user" name="nominal-1" id="nominal-1" required>
                                <option value="17000">Ya</option>
                                <option selected value="15000">Tidak</option>
                            </select>
                        </div>
                    </div>
                    <div id='setB'></div>
                    <div class="form-group text-center my-4">
                        <a href="#up" class="DEL btn btn-danger">x</a>
                        <a href="#up" id="ADD" class="btn btn-secondary">+</a>
                    </div>
                    <div class="form-group text-center my-4">
                        <button id="up" type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\mgodonf\coding\Project\Laravel\coba-lagi\resources\views/kas/create.blade.php ENDPATH**/ ?>