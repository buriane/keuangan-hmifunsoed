


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800 text-center">Uang Deposit</h1>

<div class="row">
    <div class="col-lg-6 col-sm-12">
        <div class="mb-3">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bendahara')): ?>
                <div class="d-inline">
                    <button class="btn btn-dark btn-icon-split">
                        <a href="/deposit/create" class="btn btn-dark btn-icon-split">
                            <span class="icon text-white-50">
                                <i class="fa fa-plus"></i>
                            </span>
                            <span class="text">Tambah</span>
                        </a>
                    </button>
                </div>
            <?php endif; ?>
            <div class="d-inline">
                <button class="btn btn-info btn-icon-split">
                    <a href="/deposit/history" class="btn btn-info btn-icon-split">
                        <span class="icon text-white-50">
                            <i class="fa fa-list"></i>
                        </span>
                        <span class="text">Riwayat</span>
                    </a>
                </button>
            </div>
        </div>
    </div>
    
    
</div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bendahara')): ?>
    <?php if(session()->has('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

<div class="card shadow mb-5">
    <div class="card-body">
        <div class="table-responsive" id="container">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th rowspan="2">No</th>
                        <th rowspan="2">Nama</th>
                        <th rowspan="2">Divisi</th>
                        <th colspan="6">Denda</th>
                        <th rowspan="2">Total</th>
                        <th rowspan="2">Sisa Deposit</th>
                    </tr>
                    <tr>
                        <th>Raplen</th>
                        <th>Jahim Day</th>
                        <th>Wisuda</th>
                        <th>Pesek</th>
                        <th>Proker</th>
                        <th>Lainya</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <?php
                        $raplen = $deposit->sum('raplen');
                        $jahim = $deposit->sum('jahim');
                        $wisuda = $deposit->sum('wisuda');
                        $pesek = $deposit->sum('pesek');
                        $proker = $deposit->sum('proker');
                        $lainya = $deposit->sum('lainya');
                        $total = $raplen + $jahim + $wisuda + $pesek + $proker + $lainya;
                    ?>
                    <tr>
                        <th colspan="3">Total</th>
                        <th><script> document.write(ribuan(<?php echo e($raplen); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($jahim); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($wisuda); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($pesek); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($proker); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($lainya); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e($total); ?>)) </script></th>
                        <th><script> document.write(ribuan(<?php echo e((30000 * $deposit->count()) - $total); ?>)) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $total = ($data->raplen + $data->jahim + $data->wisuda + $data->pesek + $data->proker + $data->lainya) ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->nama); ?></td>
                            <td><?php echo e($data->divisi); ?></td>
                            <td><script> document.write(ribuan(<?php echo e($data->raplen); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($data->jahim); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($data->wisuda); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($data->pesek); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($data->proker); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($data->lainya); ?>)) </script></td>
                            <td><script> document.write(ribuan(<?php echo e($total); ?>)) </script></td>
                            <td class="<?php echo e((30000-$total < 0) ? 'text-danger' : ''); ?>"><script> document.write(ribuan(<?php echo e(30000 - $total); ?>)) </script></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\mgodonf\coding\Project\Laravel\coba-lagi\resources\views/deposit/index.blade.php ENDPATH**/ ?>