


<?php $__env->startSection('content'); ?>
<?php use App\Kreus; ?> 
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800 text-center">Rekapitulasi Saldo <?php echo e($judul); ?></h1>

<div class="col-12">
    <div class="div">
        <form action="" method="get" role="form">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="row justify-content-lg-end d-flex">
                    <div class="col-5 col-lg-2 col-md-4">
                        <select id="bulan" name="bulan" type="text" class="form-control">
                            <option hidden selected value="">Bulan</option>
                            <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->bulan); ?>"><?php echo e(Kreus::bulan($data->bulan)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Proses</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow mb-5">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Sumber Dana</th>
                        <th>Pemasukan</th>
                        <th>Pengeluaran</th>
                        <th>Saldo</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <tr>
                        <th colspan="2">Total</th>
                        <th style='text-align:right ;'><script> document.write(rp( <?php echo e($total['masuk']); ?> )) </script></th>
                        <th style='text-align:right ;'><script> document.write(rp( <?php echo e($total['keluar']); ?> )) </script></th>
                        <th style='text-align:right ;'><script> document.write(rp( <?php echo e($total['masuk'] - $total['keluar']); ?> )) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $masuk = $transaksi->where('dana_id', $data->id)->where('keterangan', 'Pemasukan')->sum('nominal');
                        $keluar = $transaksi->where('dana_id', $data->id)->where('keterangan', 'Pengeluaran')->sum('nominal');
                    ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->nama); ?></td>
                            <td style='text-align:right ;'><script> document.write(rp( <?php echo e($masuk); ?> )) </script></td>
                            <td style='text-align:right ;'><script> document.write(rp( <?php echo e($keluar); ?> )) </script></td>
                            <td style='text-align:right ;'><script> document.write(rp( <?php echo e($masuk - $keluar); ?> )) </script></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\mgodonf\coding\Project\Laravel\coba-lagi\resources\views/saldo/index.blade.php ENDPATH**/ ?>