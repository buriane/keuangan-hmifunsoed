


<?php $__env->startSection('content'); ?>
<?php use App\Kreus; ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800 text-center">Laporan Keuangan Kreus <?php echo e($judul); ?></h1>

<div class="row">
    <div class="col-lg-6 col-sm-12">
        <div class="mb-3">
            <div class="dropdown no-arrow d-inline">
                <button class="btn btn-dark btn-icon-split dropdown-toggle" type="button"
                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                    aria-expanded="false">
                    <span class="icon text-white-50">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">Tambah</span>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="/laporan-kreus/create/1">Pemasukan</a>
                    <a class="dropdown-item" href="/laporan-kreus/create/2">Pengeluaran Kreus</a>
                    <a class="dropdown-item" href="/laporan-kreus/create/3">Pengeluaran diluar Kreus</a>
                </div>
            </div>
            <div class="d-inline">
                <button class="btn btn-danger btn-icon-split">
                    <a href="/laporan-kreus/manage" class="btn btn-danger btn-icon-split">
                        <span class="icon text-white-50">
                            <i class="fa fa-pencil-square-o"></i>
                        </span>
                        <span class="text">Edit</span>
                    </a>
                </button>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-12">
        <div class="div">
            <form action="" method="get" role="form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="row justify-content-lg-end d-flex">
                        <div class="col-5 col-lg-6 col-md-4">
                            <select id="bln" name="bln" type="text" class="form-control">
                                <option hidden selected value="">Pilih Bulan</option>
                                <?php $__currentLoopData = $bln; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->bulan); ?>"><?php echo e(Kreus::bulan($data->bulan)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Proses</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if(session()->has('sukses')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('sukses')); ?>

    </div>
<?php endif; ?>

<h2 class="h4 mb-3 text-gray-800">Pemasukan</h2>
<div class="card shadow mb-5">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Pemasukan Divisi Kreasi dan Usaha</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Nama Program Kerja</th>
                        <th>Sumber Dana</th>
                        <th>Penanggung Jawab</th>
                        <th>Pemasukan</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <tr>
                        <th colspan="4">Total</th>
                        <th style="text-align:right ;"><script> document.write(rp( <?php echo e($laporan->where('kategori', 'Pemasukan')->sum('pemasukan')); ?> )) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $laporan->where('kategori', 'Pemasukan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->proker); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->sumber); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->pj); ?></td>
                            <td style="text-align:right ;"><script> document.write(rp( <?php echo e($data->pemasukan); ?> )) </script></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<h2 class="h4 mb-3 text-gray-800">Pengeluaran</h2>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <ol class="mb-0">
                <li>Pengeluaran Dana untuk Program Kerja Divisi Kreasi dan Usaha</li>
            </ol>
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Nama Program Kerja</th>
                        <th>Keterangan</th>
                        <th>Penanggung Jawab</th>
                        <th>Pengeluaran</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <tr>
                        <th colspan="4">Total</th>
                        <th style="text-align:right ;"><script> document.write(rp( <?php echo e($laporan->where('kategori', 'Pengeluaran Kreus')->sum('pengeluaran')); ?> )) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $laporan->where('kategori', 'Pengeluaran Kreus'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->proker); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->keterangan); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->pj); ?></td>
                            <td style="text-align:right ;"><script> document.write(rp( <?php echo e($data->pengeluaran); ?> )) </script></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="card shadow mb-5">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <ol start="2" class="mb-0">
                <li>Pengeluaran Dana untuk Program Kerja diluar Divisi Kreasi dan Usaha</li>
            </ol>
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Program Kerja</th>
                        <th>Pengeluaran</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <tr>
                        <th colspan="3">Total</th>
                        <th style="text-align:right ;"><script> document.write(rp( <?php echo e($laporan->where('kategori', 'Pengeluaran diluar Kreus')->sum('pengeluaran')); ?> )) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $laporan->where('kategori', 'Pengeluaran diluar Kreus'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($data->tanggal); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->proker); ?></td>
                            <td style="text-align:right ;"><script> document.write(rp( <?php echo e($data->pengeluaran); ?> )) </script></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<h2 class="h4 mb-3 text-gray-800">Rekapitulasi</h2>
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>Pemasukan</th>
                        <th>Pengeluaran</th>
                    </tr>
                </thead>
                <tfoot class="text-center">
                    <tr>
                        <th colspan="2">Total</th>
                        <th style="text-align:right ;"><script> document.write(rp( <?php echo e($laporan->sum('pemasukan')); ?> )) </script></th>
                        <th style="text-align:right ;"><script> document.write(rp( <?php echo e($laporan->sum('pengeluaran')); ?> )) </script></th>
                    </tr>
                    <tr>
                        <th colspan="2">Saldo</th>
                        <th colspan="2"><script> document.write(rp( <?php echo e($laporan->sum('pemasukan') - $laporan->sum('pengeluaran')); ?> )) </script></th>
                    </tr>
                </tfoot>
                <tbody class="text-center">
                    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td style="text-align:left ;"><?php echo e($data->proker); ?> <?php echo e(($data->keterangan != null) ? '- '.$data->keterangan : ''); ?></td>
                            <?php if($data->pemasukan): ?>
                                <td style='text-align:right ;'><script> document.write(rp(<?php echo e($data->pemasukan); ?>)) </script></td>
                                <td style='text-align:right ;'>-</td>
                            <?php else: ?>
                                <td style='text-align:right ;'>-</td>
                                <td style='text-align:right ;'><script> document.write(rp(<?php echo e($data->pengeluaran); ?>)) </script></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/680/19367680/laravel/resources/views/kreus/index.blade.php ENDPATH**/ ?>