


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-3 text-gray-800 text-center">Ubah Kata Sandi</h1>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow mb-5">
            <div class="card-body">
                <form method="post" action="/ubah-kata-sandi" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="mb-3 mb-sm-0">
                            <label for="lama">Kata Sandi Lama</label>
                            <input type="password" class="<?php echo e((session('gagal1') != '') ? 'is-invalid' : ''); ?> form-control form-control-user" id="lama" name="lama" required>
                            <?php if(session()->has('gagal1')): ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e(session('gagal1')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="mb-3 mb-sm-0">
                            <label for="baru">Kata Sandi Baru</label>
                            <input type="password" class="<?php echo e((session('gagal2') != '') ? 'is-invalid' : ''); ?> <?php $__errorArgs = ['baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control form-control-user" id="baru" name="baru" required>
                            <?php $__errorArgs = ['baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="validationServer03Feedback" class="invalid-feedback">
                                Kata sandi baru minimal terdiri dari 8 karakter.
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(session()->has('gagal2')): ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e(session('gagal2')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="mb-3 mb-sm-0">
                            <label for="konfirmasi">Konfirmasi Kata Sandi Baru</label>
                            <input type="password" class="<?php echo e((session('gagal3') != '') ? 'is-invalid' : ''); ?> form-control form-control-user" id="konfirmasi" name="konfirmasi" required>
                            <?php if(session()->has('gagal2')): ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e(session('gagal2')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('gagal3')): ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e(session('gagal3')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group text-center my-4">
                        <button id="up" type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\mgodonf\coding\Project\Laravel\coba-lagi\resources\views/login/change_pass.blade.php ENDPATH**/ ?>