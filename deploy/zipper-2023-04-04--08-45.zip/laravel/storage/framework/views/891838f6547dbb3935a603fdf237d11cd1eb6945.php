


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-3 text-gray-800 text-center">Perbarui Data Pembayaran Uang Kas</h1>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow mb-5">
            <div class="card-body">
                <form method="post" action="/kas/<?php echo e($edit->id); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <label for="tanggal">Tanggal</label>
                            <input type="date" class="form-control form-control-user" value="<?php echo e($edit->tanggal); ?>" id="tanggal" name="tanggal" required>
                        </div>
                        <div class="col-sm-6">
                            <label for="dana_id">Media</label>
                            <select class="form-control form-control-user" name="dana_id" id="dana_id" required>
                                <?php $__currentLoopData = $dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(($edit->dana_id == $data->id) ? 'selected' : ''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <label for="dana_id">Nama Pengurus</label>
                            <input type="text" disabled value="<?php echo e($edit->kas->nama); ?>" class="deposit_id form-control form-control-user" required>
                            <input type="text" hidden value="<?php echo e($edit->kas_id); ?>" name="kas_id" id="kas_id" class="deposit_id form-control form-control-user" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-7 mb-3 mb-sm-0">
                            <label for="bulan">Bulan</label>
                            <select class="form-control form-control-user" name="bulan" id="bulan" required>
                                <option <?php echo e(($edit->bulan == 'April') ? 'selected' : ''); ?> value="April">April</option>
                                <option <?php echo e(($edit->bulan == 'Mei') ? 'selected' : ''); ?> value="Mei">Mei</option>
                                <option <?php echo e(($edit->bulan == 'Juni') ? 'selected' : ''); ?> value="Juni">Juni</option>
                                <option <?php echo e(($edit->bulan == 'Juli') ? 'selected' : ''); ?> value="Juli">Juli</option>
                                <option <?php echo e(($edit->bulan == 'Agustus') ? 'selected' : ''); ?> value="Agustus">Agustus</option>
                                <option <?php echo e(($edit->bulan == 'September') ? 'selected' : ''); ?> value="September">September</option>
                                <option <?php echo e(($edit->bulan == 'Oktober') ? 'selected' : ''); ?> value="Oktober">Oktober</option>
                                <option <?php echo e(($edit->bulan == 'November') ? 'selected' : ''); ?> value="November">November</option>
                            </select>
                        </div>
                        <div class="col-sm-5">
                            <label for="nominal">Denda</label>
                            <select class="form-control form-control-user" name="nominal" id="nominal-1" required>
                                <option <?php echo e(($edit->nominal == 17000) ? 'selected' : ''); ?> value="17000">Ya</option>
                                <option <?php echo e(($edit->nominal == 15000) ? 'selected' : ''); ?> value="15000">Tidak</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center my-4">
                        <button id="up" type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\mgodonf\coding\Project\Laravel\coba-lagi\resources\views/kas/edit.blade.php ENDPATH**/ ?>