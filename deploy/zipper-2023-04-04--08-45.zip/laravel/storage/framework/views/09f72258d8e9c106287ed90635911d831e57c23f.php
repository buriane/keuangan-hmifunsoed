


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-3 text-gray-800 text-center">Perbarui Data Pengurangan Deposit</h1>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow mb-5">
            <div class="card-body">
                <form method="post" action="/deposit/<?php echo e($edit->id); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group row">
                        <div class="col-sm-4 mb-3 mb-sm-0">
                            <label for="tanggal">Tanggal</label>
                            <input type="date" value="<?php echo e($edit->tanggal); ?>" class="form-control form-control-user" id="tanggal" name="tanggal" required>
                        </div>
                        <div class="col-sm-8">
                            <label for="dana_id">Nama Pengurus</label>
                            <select class="form-control form-control-user" name="deposit_id" id="deposit_id" required>
                                <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $d = $nama->where('divisi', $div->divisi) ?>
                                    <option value="" class="font-weight-bold" disabled><?php echo e($div->divisi); ?></option>
                                    <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(($edit->deposit_id == $data->id) ? 'selected' : ''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-7 mb-3 mb-sm-0">
                            <label for="keterangan">Keterangan</label>
                            <select class="form-control form-control-user" name="keterangan" id="keterangan" required>
                                <option <?php echo e(($edit->keterangan == 'Tidak mengikuti rapat pleno') ? 'selected' : ''); ?> value="Tidak mengikuti rapat pleno">Tidak mengikuti rapat pleno</option>
                                <option <?php echo e(($edit->keterangan == 'Terlambat mengikuti rapat pleno') ? 'selected' : ''); ?> value="Terlambat mengikuti rapat pleno">Terlambat mengikuti rapat pleno</option>
                                <option <?php echo e(($edit->keterangan == 'Tidak menggunakan jahim ketika jahim day') ? 'selected' : ''); ?> value="Tidak menggunakan jahim ketika jahim day">Tidak menggunakan jahim ketika jahim day</option>
                                <option <?php echo e(($edit->keterangan == 'Tidak mengikuti wisuda offline') ? 'selected' : ''); ?> value="Tidak mengikuti wisuda offline">Tidak mengikuti wisuda offline</option>
                                <option <?php echo e(($edit->keterangan == 'Tidak mengikuti piket pesek') ? 'selected' : ''); ?> value="Tidak mengikuti piket pesek">Tidak mengikuti piket pesek</option>
                                <option <?php echo e(($edit->keterangan == 'Tidak ada kabar saat menjalankan proker') ? 'selected' : ''); ?> value="Tidak ada kabar saat menjalankan proker">Tidak ada kabar saat menjalankan proker</option>
                                <option <?php echo e(($edit->keterangan == 'Lainya') ? 'selected' : ''); ?> value="Lainya">Lainya</option>
                            </select>
                        </div>
                        <div class="col-sm-5">
                            <label for="nominal">Nominal</label>
                            <input type="number" value="<?php echo e($edit->nominal); ?>" class="form-control form-control-user" id="nominal" name="nominal" placeholder="Masukkan Nominal" required>
                        </div>
                    </div>
                    <div class="form-group text-center my-4">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/680/19367680/laravel/resources/views/deposit/edit.blade.php ENDPATH**/ ?>