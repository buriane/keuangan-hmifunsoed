


<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-3 text-gray-800 text-center">Perbarui Data</h1>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow mb-5">
            <div class="card-header py-3">
                <h5 class="m-0 font-weight-bold text-primary text-center">Pengeluaran Divisi Kreasi dan Usaha</h5>
            </div>
            <div class="card-body">
                <form method="post" action="/laporan-kreus/<?php echo e($data->id); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group row">
                        <input type="text" name="kategori" id="kategori" value="Pengeluaran Kreus" hidden>
                        <div class="col-sm-4 mb-3 mb-sm-0">
                            <label for="bulan">Bulan</label>
                            <select class="form-control form-control-user" name="bulan" id="bulan" required>
                                <option value="1" <?php echo e(($data->bulan === 1) ? 'selected' : ''); ?>>Januari</option>
                                <option value="2" <?php echo e(($data->bulan === 2) ? 'selected' : ''); ?>>Februari</option>
                                <option value="3" <?php echo e(($data->bulan === 3) ? 'selected' : ''); ?>>Maret</option>
                                <option value="4" <?php echo e(($data->bulan === 4) ? 'selected' : ''); ?>>April</option>
                                <option value="5" <?php echo e(($data->bulan === 5) ? 'selected' : ''); ?>>Mei</option>
                                <option value="6" <?php echo e(($data->bulan === 6) ? 'selected' : ''); ?>>Juni</option>
                                <option value="7" <?php echo e(($data->bulan === 7) ? 'selected' : ''); ?>>Juli</option>
                                <option value="8" <?php echo e(($data->bulan === 8) ? 'selected' : ''); ?>>Agustus</option>
                                <option value="9" <?php echo e(($data->bulan === 9) ? 'selected' : ''); ?>>September</option>
                                <option value="10" <?php echo e(($data->bulan === 10) ? 'selected' : ''); ?>>Oktober</option>
                                <option value="11" <?php echo e(($data->bulan === 11) ? 'selected' : ''); ?>>November</option>
                                <option value="12" <?php echo e(($data->bulan === 12) ? 'selected' : ''); ?>>Desember</option>
                            </select>
                        </div>
                        <div class="col-sm-8">
                            <label for="proker">Program Kerja</label>
                            <input type="text" class="form-control form-control-user" id="proker" value="<?php echo e($data->proker); ?>" name="proker" placeholder="Masukkan Program Kerja" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-7 mb-3 mb-sm-0">
                            <label for="sumber">Keterangan</label>
                            <input type="text" class="form-control form-control-user" id="keterangan" value="<?php echo e($data->keterangan); ?>" name="keterangan" placeholder="Masukkan Keterangan" required>
                        </div>
                        <div class="col-sm-5">
                            <label for="pemasukan">Nominal</label>
                            <input type="number" class="form-control form-control-user" id="pengeluaran" value="<?php echo e($data->pengeluaran); ?>" name="pengeluaran" placeholder="Masukkan Nominal" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pj">Penanggung Jawab</label>
                        <input type="text" class="form-control form-control-user" id="pj" value="<?php echo e($data->pj); ?>" name="pj" placeholder="Masukkan Penanggung Jawab" required>
                    </div>
                    <div class="form-group text-center my-4">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/680/19367680/laravel/resources/views/kreus/edit-2.blade.php ENDPATH**/ ?>